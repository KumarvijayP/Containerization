#!/bin/bash
#$1==>ContainerName
#$2==>mountDirectory
#$3==>MySQLRootPassword
#$4==>ImageName
#docker run -d -p 3306:3306 --name $1 -v $2:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=$3 $4 

docker run -d -p 3306:3306 --name my-mysql -v /mnt/sda1/var/mysql_data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=mysql my-mysql 

