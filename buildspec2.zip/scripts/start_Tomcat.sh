#!/bin/bash
#$1==>DBConnection
#$2==>MySQLuserName
#$3==>MySQLRootPassword
#$4==>MountDirectory
#$5==>ImageName

#docker run -e DBConnection=$1 -e userName=$2 -e password=$3 -v $4:/usr/local/tomcat/webapps -d -p 8088:8080 $5

docker run -e DBConnection=jdbc:mysql://localhost:3306/test -e userName=root -e password=mysql -v /home/ec2-user/HelloWorldJavaWar/webapps:/usr/local/tomcat/webapps -d -p 8088:8080 hello-world-war:v1.0