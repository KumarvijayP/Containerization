#!/bin/bash
sudo su
yum install docker
mkdir -p /mnt/sda1/var/mysql_data
mkdir -p /home/ec2-user/HelloWorldJavaWar/webapps



